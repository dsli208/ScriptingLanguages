$password = <STDIN>;
if($password==100){
	print "Correct password";

} else{

	print "Incorrect password";
}

