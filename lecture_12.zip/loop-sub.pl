while (<>) {
s/freind/friend/g; 
s/teh/the/g;
s/jsut/just/g;
s/pual/Paul/ig;
print;
}
