from bs4 import BeautifulSoup

import urllib

def get_daily_forecast(day):
    period = day.find(class_="period-name").get_text()
    short_desc = day.find(class_="short-desc").get_text()
    temp = day.find(class_="temp").get_text()
    return period, short_desc, temp 

def get_daily_description(day):
    img = day.find("img")
    desc = img['title']
    return desc


weather_url = "http://forecast.weather.gov/MapClick.php?lat=40.9128&lon=-73.1399"
r = urllib.urlopen(weather_url)
soup = BeautifulSoup(r,"html.parser")
daily_forecasts = soup.find_all(class_="tombstone-container")
print "Number of records:" , len(daily_forecasts)
f = open("weather_log.txt","a")

for forecast in daily_forecasts:
    period, short_desc, temp = get_daily_forecast(forecast)
    desc = get_daily_description(forecast)
    f.write(period.encode('utf-8') + " " + short_desc.encode('utf-8') + " " + temp.encode('utf-8') + " " + desc.encode('utf-8')+"\n")
