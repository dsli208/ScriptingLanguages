#!/usr/bin/perl
# The Perl version of "Hello, world."
use strict;
use warnings;

print "Just another Perl hacker.\n";

