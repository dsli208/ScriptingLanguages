$a=10;
$b="a";
$c=$a.$b;
print $c; 


$a=10;
$b="a";
$c=$a+$b;
print $c;


$a=10;
$b="20a";
$c=$a+$b;
print $c;
